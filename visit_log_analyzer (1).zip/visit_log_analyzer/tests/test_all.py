import json, os, tempfile, unittest
from pathlib import Path

from analyzer import analytics, queries, report
from analyzer.models import VisitRecord
from analyzer.storage import Storage
from analyzer import validation as v

ROOT = Path(__file__).resolve().parent.parent


def rec(i, d, r, n, p="/"):
    return VisitRecord(i, d, r, p, n)


class TestValidation(unittest.TestCase):
    def test_date(self):
        self.assertEqual(v.validate_date(" 2026-11-25 "), "2026-11-25")
        for bad in ["2026-13-01", "2026-02-30", "25/11/2026", "", "abc"]:
            with self.assertRaises(ValueError): v.validate_date(bad)

    def test_visits_boundaries(self):
        self.assertEqual(v.validate_visits("0"), 0)
        self.assertEqual(v.validate_visits("1,250"), 1250)
        self.assertEqual(v.validate_visits("1000000"), 1_000_000)
        for bad in ["1000001", "-1", "3.5", "abc", "", "  "]:
            with self.assertRaises(ValueError): v.validate_visits(bad)

    def test_referrer_and_page(self):
        self.assertEqual(v.validate_referrer("  Google  "), "google")
        with self.assertRaises(ValueError): v.validate_referrer("   ")
        with self.assertRaises(ValueError): v.validate_referrer("<script>")
        self.assertEqual(v.validate_page("pricing"), "/pricing")
        self.assertEqual(v.validate_page(""), "/")
        with self.assertRaises(ValueError): v.validate_page("/bad page!")

    def test_prompt_loops_until_valid(self):
        answers = iter(["abc", "-5", "42"])
        import builtins
        orig = builtins.input
        builtins.input = lambda _="": next(answers)
        errors = []
        try:
            self.assertEqual(v.prompt("n", v.validate_visits, on_error=errors.append), 42)
        finally:
            builtins.input = orig
        self.assertEqual(len(errors), 2)


class TestAnalytics(unittest.TestCase):
    def setUp(self):
        self.recs = [rec(1, "2026-11-01", "google", 100), rec(2, "2026-11-01", "direct", 50),
                     rec(3, "2026-11-02", "google", 200), rec(4, "2026-11-04", "direct", 0)]

    def test_by_day(self):
        d = analytics.summarize_by_day(self.recs)
        self.assertEqual([(x["date"], x["visits"]) for x in d],
                         [("2026-11-01", 150), ("2026-11-02", 200), ("2026-11-04", 0)])

    def test_by_referrer_shares(self):
        r = analytics.summarize_by_referrer(self.recs)
        self.assertEqual(r[0]["referrer"], "google")
        self.assertAlmostEqual(sum(x["share"] for x in r), 100.0)
        self.assertAlmostEqual(r[0]["share"], 300 / 350 * 100)

    def test_warnings(self):
        s = analytics.executive_summary(self.recs)
        text = " ".join(s["warnings"])
        self.assertIn("0 visits", text)
        self.assertIn("2026-11-03", text)       # gap day
        self.assertIn("google", text)           # >50% concentration

    def test_spike(self):
        recs = [rec(i, f"2026-11-{i:02d}", "google", 100) for i in range(1, 9)] + [rec(9, "2026-11-09", "google", 5000)]
        self.assertTrue(any("spike" in w for w in analytics.executive_summary(recs)["warnings"]))

    def test_trend(self):
        up = [{"date": str(i), "visits": 100 + 50 * i} for i in range(6)]
        self.assertEqual(analytics.compute_trend(up)[0], "Rising")
        flat = [{"date": str(i), "visits": 100} for i in range(6)]
        self.assertEqual(analytics.compute_trend(flat)[0], "Stable")

    def test_empty(self):
        self.assertTrue(analytics.executive_summary([])["empty"])
        self.assertIn("No data", report.summary_lines([])[0])


class TestQueries(unittest.TestCase):
    def test_filters(self):
        recs = [rec(1, "2026-11-01", "google", 100, "/pricing"), rec(2, "2026-11-02", "direct", 10)]
        self.assertEqual(len(queries.search(recs, "pric")), 1)
        self.assertEqual(len(queries.search(recs, referrer="direct")), 1)
        self.assertEqual(len(queries.search(recs, date_from="2026-11-02")), 1)
        self.assertEqual(len(queries.search(recs, min_visits=50)), 1)
        self.assertEqual(len(queries.search(recs, "zzz")), 0)


class TestStorage(unittest.TestCase):
    def test_roundtrip_and_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            s = Storage(d); s.load()
            s.add("2026-11-01", "google", "/", 10)
            s2 = Storage(d); s2.load()
            self.assertEqual(len(s2.records), 1)
            self.assertEqual(s2.next_id(), 2)

    def test_missing_file_created(self):
        with tempfile.TemporaryDirectory() as d:
            s = Storage(d); s.load()
            self.assertTrue((Path(d) / "visits.json").exists())

    def test_corrupted_file_recovered(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "visits.json").write_text("{not json!!")
            s = Storage(d); s.load()
            self.assertEqual(s.records, [])
            self.assertTrue(any("corrupt" in p.name for p in Path(d).iterdir()))
            self.assertTrue(s.load_notes)

    def test_bad_records_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "visits.json").write_text(json.dumps({"records": [
                {"id": 1, "date": "2026-11-01", "referrer": "google", "page": "/", "visits": 5},
                {"id": 2, "date": "garbage", "referrer": "x", "page": "/", "visits": 5},
                {"id": 3}]}))
            s = Storage(d); s.load()
            self.assertEqual(len(s.records), 1)

    def test_import_with_errors(self):
        with tempfile.TemporaryDirectory() as d:
            s = Storage(d); s.load()
            n, errs = s.import_csv(ROOT / "data" / "sample_legacy_with_errors.csv")
            self.assertEqual(n, 3)
            self.assertEqual(len(errs), 7)
            self.assertEqual(errs[0][0], 4)   # first bad row is CSV line 4
            self.assertTrue((Path(d) / "import_errors.log").exists())

    def test_import_missing_columns(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "bad.csv"; p.write_text("foo,bar\n1,2\n")
            with self.assertRaises(ValueError): Storage(d).import_csv(p)

    def test_sample_data_all_valid(self):
        with tempfile.TemporaryDirectory() as d:
            s = Storage(d); s.load()
            n, errs = s.import_csv(ROOT / "data" / "sample_visits.csv")
            self.assertEqual(errs, [])
            self.assertGreaterEqual(n, 30)


class TestReport(unittest.TestCase):
    def test_export_all_formats(self):
        recs = [rec(1, "2026-11-01", "google", 100), rec(2, "2026-11-02", "direct", 50)]
        with tempfile.TemporaryDirectory() as d:
            paths = report.export_report(recs, d)
            for p in paths.values(): self.assertGreater(p.stat().st_size, 0)
            self.assertIn("# Website Visit Log Report", paths["md"].read_text())

    def test_table_fixed_width(self):
        t = report.format_table(["A", "B"], [["xx", 1], ["y", 22]], "lr").splitlines()
        self.assertEqual(len({len(line) for line in t}), 1)


if __name__ == "__main__":
    unittest.main()
