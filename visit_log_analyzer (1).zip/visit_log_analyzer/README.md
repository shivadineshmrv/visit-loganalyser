# Website Visit Log Analyzer

A beginner-friendly Python terminal app that summarises website visits **by day and referrer** from CSV
logs, with strict input validation, JSON persistence, search, executive summaries, warnings,
Matplotlib charts and multi-format report export.

Requires **Python 3.10+**. Only `matplotlib` is external (optional - a text chart is used if absent).

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python main.py
```
Run tests: `python -m unittest discover -s tests -t .`

## Menu
| # | Feature | Notes |
|---|---------|-------|
| 1 | Add record | validated: real date, referrer, page path, visits 0-1,000,000 |
| 2 | View records | paginated fixed-width table |
| 3 | Search / filter | keyword, referrer, date range, min visits |
| 4 | Delete record | with confirmation |
| 5 / 6 | Summary by day / referrer | totals and traffic share |
| 7 | Executive summary | totals, average, peak/low, top referrer, trend, **warnings**, day x referrer matrix |
| 8 | Charts | `charts/`: daily trend, referrer distribution, stacked daily-by-referrer |
| 9 | Export | `reports/`: Markdown, plain-text audit log, CSV |
| 10 | Bulk CSV import | row-by-row error log in `data/import_errors.log` |
| 11 | Load sample data | 39 realistic rows incl. a spike, a gap day and edge values |

Type `:q` at any prompt to cancel the current action.

## Warning rules (`analyzer/analytics.py`)
- **Traffic spike**: a day >= 2 standard deviations above the daily mean (needs 5+ days)
- **Referrer concentration**: one referrer supplies > 50% of visits
- **Zero-visit entries** and **missing days** within the logged date range

## Robustness
- Missing `data/visits.json` -> clean file auto-created
- Corrupted JSON -> backed up as `visits.corrupt-<timestamp>.json`, app starts fresh
- Invalid individual records are skipped on load, never crash the app
- Atomic saves (temp file + replace) so a crash can't corrupt data
- Validation loops until input is valid; Ctrl+C / Ctrl+D exits cleanly

## CSV format
Required columns: `date, referrer, visits`. Optional: `page`. See `data/sample_visits.csv`.
`data/sample_legacy_with_errors.csv` has 3 good and 7 bad rows to demo the import error log.

## 3-minute demo script
1. `python main.py` - show the banner. Choose **11** to load sample data.
2. Choose **1**, enter `2026-02-30`, then `25/11/2026`, then a blank referrer, and `abc` visits. Show each rejection, then enter valid values.
3. Choose **7** for the summary, warnings and matrix; choose **5** and **6** for the tables.
4. Choose **10** (press Enter for the default legacy file) to show the row-level error report.
5. Exit with **0**, relaunch, choose **2** to prove the data persisted.
6. Choose **8** and **9**, then open `charts/` and `reports/`.

## Project layout
```
main.py                  entry point
analyzer/
  validation.py          validators + centralised prompt() wrapper
  storage.py             JSON store, CSV import/export, corruption recovery
  analytics.py           summaries, trend, warnings
  queries.py             search / filter
  report.py              tables + MD/TXT/CSV export
  plotting.py            Matplotlib charts (+ text fallback)
  ui.py                  menu loop and ANSI formatting
data/                    sample CSV / JSON datasets
tests/test_all.py        20 unit tests
generate_sample_data.py  regenerates the sample datasets
```
