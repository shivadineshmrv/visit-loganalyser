"""Matplotlib chart generation with graceful fallback if matplotlib is missing."""
from __future__ import annotations

from pathlib import Path

from .analytics import summarize_by_day, summarize_by_referrer
from .models import VisitRecord


def matplotlib_available() -> bool:
    try:
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def text_bar_chart(records: list[VisitRecord], width: int = 40) -> str:
    """ASCII fallback used when matplotlib isn't installed."""
    rows = summarize_by_referrer(records)
    if not rows:
        return "(no data)"
    top = max(r["visits"] for r in rows) or 1
    return "\n".join(f"{r['referrer']:<14}{'#' * max(1 if r['visits'] else 0, round(r['visits'] / top * width))} "
                     f"{r['visits']:,}" for r in rows)


def generate_charts(records: list[VisitRecord], out_dir: str | Path = "charts") -> list[Path]:
    """Create trend line + referrer distribution PNGs. Raises ImportError if unavailable."""
    import matplotlib
    matplotlib.use("Agg")  # headless-safe backend
    import matplotlib.pyplot as plt

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    daily = summarize_by_day(records)
    by_ref = summarize_by_referrer(records)
    paths: list[Path] = []

    # 1) Daily trend
    fig, ax = plt.subplots(figsize=(9, 4.5))
    labels = [d["date"][5:] for d in daily]
    values = [d["visits"] for d in daily]
    ax.plot(labels, values, marker="o", linewidth=2, color="#2563eb")
    ax.fill_between(labels, values, alpha=0.12, color="#2563eb")
    ax.set_title("Total Visits per Day")
    ax.set_xlabel("Date (MM-DD)")
    ax.set_ylabel("Visits")
    ax.grid(alpha=0.3)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout()
    p1 = out / "daily_trend.png"
    fig.savefig(p1, dpi=130)
    plt.close(fig)
    paths.append(p1)

    # 2) Referrer distribution (bar + share labels)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    names = [r["referrer"] for r in by_ref]
    vals = [r["visits"] for r in by_ref]
    bars = ax.barh(names[::-1], vals[::-1], color="#10b981")
    for bar, r in zip(bars, by_ref[::-1]):
        ax.text(bar.get_width(), bar.get_y() + bar.get_height() / 2,
                f"  {r['visits']:,} ({r['share']:.1f}%)", va="center", fontsize=9)
    ax.set_title("Visits by Referrer")
    ax.set_xlabel("Visits")
    ax.set_xlim(0, (max(vals) if vals else 1) * 1.25)
    fig.tight_layout()
    p2 = out / "referrer_distribution.png"
    fig.savefig(p2, dpi=130)
    plt.close(fig)
    paths.append(p2)

    # 3) Stacked daily by referrer
    days = [d["date"] for d in daily]
    fig, ax = plt.subplots(figsize=(9, 4.5))
    bottom = [0] * len(days)
    for ref in names:
        series = [sum(r.visits for r in records if r.date == d and r.referrer == ref) for d in days]
        ax.bar([d[5:] for d in days], series, bottom=bottom, label=ref)
        bottom = [b + s for b, s in zip(bottom, series)]
    ax.set_title("Daily Visits Stacked by Referrer")
    ax.set_xlabel("Date (MM-DD)")
    ax.set_ylabel("Visits")
    ax.legend(fontsize=8, ncol=2)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout()
    p3 = out / "daily_by_referrer.png"
    fig.savefig(p3, dpi=130)
    plt.close(fig)
    paths.append(p3)
    return paths
