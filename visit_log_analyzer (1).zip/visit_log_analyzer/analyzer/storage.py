"""Local persistence (JSON store, CSV import/export) with corruption recovery."""
from __future__ import annotations

import csv
import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Iterable

from .models import VisitRecord
from .validation import (validate_date, validate_page, validate_referrer,
                         validate_visits)

CSV_FIELDS = ["id", "date", "referrer", "page", "visits"]


class Storage:
    def __init__(self, data_dir: str | Path = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.data_dir / "visits.json"
        self.records: list[VisitRecord] = []
        self.load_notes: list[str] = []

    # ---------- load / save ----------
    def load(self) -> list[VisitRecord]:
        self.load_notes = []
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            if not isinstance(payload, dict) or not isinstance(payload.get("records"), list):
                raise ValueError("unexpected JSON structure")
        except FileNotFoundError:
            self.records = []
            self.save()
            self.load_notes.append("No data file found - created a clean one.")
            return self.records
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError):
            backup = self.path.with_suffix(f".corrupt-{datetime.now():%Y%m%d-%H%M%S}.json")
            shutil.move(str(self.path), str(backup))
            self.records = []
            self.save()
            self.load_notes.append(f"Data file was corrupted. Backed up to '{backup.name}' and started fresh.")
            return self.records

        good, skipped = [], 0
        for item in payload["records"]:
            try:
                rec = VisitRecord.from_dict(item)
                rec.date = validate_date(rec.date)
                rec.referrer = validate_referrer(rec.referrer)
                rec.page = validate_page(rec.page)
                rec.visits = validate_visits(str(rec.visits))
                good.append(rec)
            except (KeyError, TypeError, ValueError):
                skipped += 1
        if skipped:
            self.load_notes.append(f"Skipped {skipped} invalid record(s) while loading.")
        self.records = good
        return self.records

    def save(self) -> None:
        """Atomic write: temp file then replace, so a crash can't corrupt data."""
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"version": 1, "records": [r.to_dict() for r in self.records]}, fh, indent=2)
        os.replace(tmp, self.path)

    # ---------- mutations ----------
    def next_id(self) -> int:
        return max((r.id for r in self.records), default=0) + 1

    def add(self, date: str, referrer: str, page: str, visits: int) -> VisitRecord:
        rec = VisitRecord(self.next_id(), date, referrer, page, visits)
        self.records.append(rec)
        self.save()
        return rec

    def delete(self, record_id: int) -> bool:
        before = len(self.records)
        self.records = [r for r in self.records if r.id != record_id]
        changed = len(self.records) != before
        if changed:
            self.save()
        return changed

    # ---------- CSV ----------
    def import_csv(self, csv_path: str | Path) -> tuple[int, list[tuple[int, str]]]:
        """Bulk import. Returns (rows_imported, [(row_number, reason), ...]).
        Valid rows are imported even if others fail; failures go to import_errors.log."""
        errors: list[tuple[int, str]] = []
        new_records: list[VisitRecord] = []
        next_id = self.next_id()
        with open(csv_path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            headers = {h.strip().lower() for h in (reader.fieldnames or [])}
            missing = {"date", "referrer", "visits"} - headers
            if missing:
                raise ValueError(f"CSV is missing required column(s): {', '.join(sorted(missing))}")
            for row_no, row in enumerate(reader, start=2):  # row 1 = header
                row = {(k or "").strip().lower(): (v or "") for k, v in row.items()}
                try:
                    rec = VisitRecord(
                        id=next_id,
                        date=validate_date(row.get("date", "")),
                        referrer=validate_referrer(row.get("referrer", "")),
                        page=validate_page(row.get("page", "")),
                        visits=validate_visits(row.get("visits", "")),
                    )
                except ValueError as exc:
                    errors.append((row_no, str(exc)))
                    continue
                new_records.append(rec)
                next_id += 1
        self.records.extend(new_records)
        if new_records:
            self.save()
        log = self.data_dir / "import_errors.log"
        with open(log, "w", encoding="utf-8") as fh:
            fh.write(f"Import of {csv_path} at {datetime.now():%Y-%m-%d %H:%M:%S}\n")
            fh.write(f"Imported: {len(new_records)}  Rejected: {len(errors)}\n")
            for row_no, reason in errors:
                fh.write(f"  row {row_no}: {reason}\n")
        return len(new_records), errors

    @staticmethod
    def write_csv(path: str | Path, records: Iterable[VisitRecord]) -> None:
        with open(path, "w", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for r in records:
                writer.writerow(r.to_dict())
