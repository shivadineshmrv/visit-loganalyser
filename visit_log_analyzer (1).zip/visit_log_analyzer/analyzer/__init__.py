"""Website Visit Log Analyzer - core package."""
__version__ = "1.0.0"
