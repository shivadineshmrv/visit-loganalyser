"""Table formatting and multi-format report export (Markdown / TXT / CSV)."""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from .analytics import (day_referrer_matrix, executive_summary,
                        summarize_by_day, summarize_by_referrer)
from .models import VisitRecord


def format_table(headers: list[str], rows: list[list], aligns: str | None = None) -> str:
    """Fixed-width text table. aligns: string of 'l'/'r' per column."""
    aligns = aligns or "l" * len(headers)
    str_rows = [[str(c) for c in row] for row in rows]
    widths = [max([len(h)] + [len(r[i]) for r in str_rows]) for i, h in enumerate(headers)]

    def fmt(cells: list[str]) -> str:
        parts = [c.rjust(w) if a == "r" else c.ljust(w) for c, w, a in zip(cells, widths, aligns)]
        return "| " + " | ".join(parts) + " |"

    sep = "+-" + "-+-".join("-" * w for w in widths) + "-+"
    lines = [sep, fmt(headers), sep] + [fmt(r) for r in str_rows] + [sep]
    return "\n".join(lines)


def records_table(records: list[VisitRecord]) -> str:
    return format_table(["ID", "Date", "Referrer", "Page", "Visits"],
                        [[r.id, r.date, r.referrer, r.page, f"{r.visits:,}"] for r in records], "rlllr")


def day_table(records: list[VisitRecord]) -> str:
    daily = summarize_by_day(records)
    return format_table(["Date", "Entries", "Visits"],
                        [[d["date"], d["entries"], f"{d['visits']:,}"] for d in daily], "lrr")


def referrer_table(records: list[VisitRecord]) -> str:
    rows = summarize_by_referrer(records)
    return format_table(["Referrer", "Visits", "Share"],
                        [[r["referrer"], f"{r['visits']:,}", f"{r['share']:.1f}%"] for r in rows], "lrr")


def matrix_table(records: list[VisitRecord]) -> str:
    days, refs, cell = day_referrer_matrix(records)
    rows = [[d] + [f"{cell.get((d, r), 0):,}" for r in refs] + [f"{sum(cell.get((d, r), 0) for r in refs):,}"]
            for d in days]
    return format_table(["Date"] + refs + ["Total"], rows, "l" + "r" * (len(refs) + 1))


def summary_lines(records: list[VisitRecord]) -> list[str]:
    s = executive_summary(records)
    if s["empty"]:
        return ["No data available. Add records or import a CSV first."]
    arrow = {"Rising": "^", "Falling": "v", "Stable": "-"}.get(s["trend"], "?")
    return [
        f"Period            : {s['date_range'][0]} to {s['date_range'][1]} ({s['days']} days with data)",
        f"Total visits      : {s['total_visits']:,}  across {s['entries']} entries",
        f"Average per day   : {s['avg_per_day']:,.1f}",
        f"Peak day          : {s['peak_day']['date']} ({s['peak_day']['visits']:,})",
        f"Lowest day        : {s['lowest_day']['date']} ({s['lowest_day']['visits']:,})",
        f"Top referrer      : {s['top_referrer']['referrer']} "
        f"({s['top_referrer']['visits']:,} visits, {s['top_referrer']['share']:.1f}%)",
        f"Trend             : {s['trend']} {arrow} ({s['trend_change_pct']:+.1f}% 2nd half vs 1st half)",
    ]


def export_report(records: list[VisitRecord], out_dir: str | Path = "reports") -> dict[str, Path]:
    """Write .md, .txt and .csv reports. Returns {format: path}."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    s = executive_summary(records)
    paths = {"md": out / f"report-{stamp}.md", "txt": out / f"report-{stamp}.txt",
             "csv": out / f"report-{stamp}.csv"}
    generated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Markdown
    md = [f"# Website Visit Log Report", f"_Generated {generated}_", "", "## Executive Summary", ""]
    md += [f"- {line}" for line in summary_lines(records)]
    if not s["empty"]:
        md += ["", "## Warnings", ""] + ([f"- WARNING: {w}" for w in s["warnings"]] or ["- None"])
        md += ["", "## Visits by Day", "", "| Date | Entries | Visits |", "|---|---:|---:|"]
        md += [f"| {d['date']} | {d['entries']} | {d['visits']:,} |" for d in summarize_by_day(records)]
        md += ["", "## Visits by Referrer", "", "| Referrer | Visits | Share |", "|---|---:|---:|"]
        md += [f"| {r['referrer']} | {r['visits']:,} | {r['share']:.1f}% |" for r in summarize_by_referrer(records)]
    paths["md"].write_text("\n".join(md) + "\n", encoding="utf-8")

    # Plain-text audit log
    txt = ["WEBSITE VISIT LOG REPORT", f"Generated: {generated}", "=" * 60, "", "EXECUTIVE SUMMARY"]
    txt += summary_lines(records)
    if not s["empty"]:
        txt += ["", "WARNINGS"] + ([f"  ! {w}" for w in s["warnings"]] or ["  None"])
        txt += ["", "VISITS BY DAY", day_table(records), "", "VISITS BY REFERRER", referrer_table(records),
                "", "DAY x REFERRER MATRIX", matrix_table(records)]
    paths["txt"].write_text("\n".join(txt) + "\n", encoding="utf-8")

    # CSV (long format: day, referrer, visits)
    days, refs, cell = day_referrer_matrix(records)
    with open(paths["csv"], "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["date", "referrer", "visits"])
        for d in days:
            for r in refs:
                if (d, r) in cell:
                    w.writerow([d, r, cell[(d, r)]])
    return paths
