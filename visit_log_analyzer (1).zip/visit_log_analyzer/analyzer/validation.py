"""Defensive validation + centralised input wrappers.

Every validator takes a raw string and returns a cleaned value, or raises
ValueError with a human-readable message.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Callable, Optional, TypeVar

MAX_VISITS = 1_000_000
MIN_DATE = datetime(2000, 1, 1)
MAX_DATE = datetime(2100, 12, 31)

_REFERRER_RE = re.compile(r"^[a-z0-9][a-z0-9 ._\-/:]{0,59}$")
_PAGE_RE = re.compile(r"^/[A-Za-z0-9._~\-/]{0,99}$")

T = TypeVar("T")


class Cancelled(Exception):
    """Raised when the user types ':q' at a prompt."""


def validate_date(raw: str) -> str:
    raw = raw.strip()
    try:
        d = datetime.strptime(raw, "%Y-%m-%d")
    except ValueError:
        raise ValueError("Date must be a real calendar date in YYYY-MM-DD format (e.g. 2026-11-25).")
    if not (MIN_DATE <= d <= MAX_DATE):
        raise ValueError("Date must be between 2000-01-01 and 2100-12-31.")
    return d.strftime("%Y-%m-%d")


def validate_referrer(raw: str) -> str:
    cleaned = " ".join(raw.strip().lower().split())
    if not cleaned:
        raise ValueError("Referrer cannot be blank (use 'direct' for no referrer).")
    if not _REFERRER_RE.match(cleaned):
        raise ValueError("Referrer may contain letters, digits, space and . _ - / : (max 60 chars).")
    return cleaned


def validate_page(raw: str) -> str:
    cleaned = raw.strip()
    if cleaned == "":
        return "/"
    if not cleaned.startswith("/"):
        cleaned = "/" + cleaned
    if not _PAGE_RE.match(cleaned):
        raise ValueError("Page must be a URL path like /pricing (letters, digits, . _ ~ - /).")
    return cleaned


def validate_visits(raw: str) -> int:
    cleaned = raw.strip().replace(",", "")
    if cleaned == "":
        raise ValueError("Visits cannot be blank.")
    if not re.fullmatch(r"\d+", cleaned):
        raise ValueError("Visits must be a whole, non-negative number (digits only).")
    value = int(cleaned)
    if value > MAX_VISITS:
        raise ValueError(f"Visits must be at most {MAX_VISITS:,}.")
    return value


def validate_optional_date(raw: str) -> Optional[str]:
    return None if raw.strip() == "" else validate_date(raw)


def validate_optional_int(raw: str) -> Optional[int]:
    return None if raw.strip() == "" else validate_visits(raw)


def validate_menu_choice(valid: set[str]) -> Callable[[str], str]:
    def _v(raw: str) -> str:
        c = raw.strip()
        if c not in valid:
            raise ValueError(f"Please choose one of: {', '.join(sorted(valid, key=lambda x: (len(x), x)))}")
        return c
    return _v


def prompt(label: str, validator: Callable[[str], T], default: Optional[str] = None,
           on_error: Callable[[str], None] = print) -> T:
    """Loop until `validator` accepts the input. ':q' cancels the operation."""
    suffix = f" [{default}]" if default is not None else ""
    while True:
        raw = input(f"{label}{suffix}: ").strip()
        if raw.lower() == ":q":
            raise Cancelled()
        if raw == "" and default is not None:
            raw = default
        try:
            return validator(raw)
        except ValueError as exc:
            on_error(str(exc))
