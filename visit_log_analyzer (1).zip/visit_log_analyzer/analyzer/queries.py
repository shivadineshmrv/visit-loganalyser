"""Keyword / category based record retrieval."""
from __future__ import annotations

from typing import Optional

from .models import VisitRecord


def search(records: list[VisitRecord], keyword: str = "", referrer: Optional[str] = None,
           date_from: Optional[str] = None, date_to: Optional[str] = None,
           min_visits: Optional[int] = None) -> list[VisitRecord]:
    kw = keyword.strip().lower()
    out = []
    for r in records:
        if kw and kw not in f"{r.date} {r.referrer} {r.page}".lower():
            continue
        if referrer and r.referrer != referrer.lower():
            continue
        if date_from and r.date < date_from:
            continue
        if date_to and r.date > date_to:
            continue
        if min_visits is not None and r.visits < min_visits:
            continue
        out.append(r)
    return sorted(out, key=lambda r: (r.date, r.id))
