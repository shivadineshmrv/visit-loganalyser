"""Data model for a single visit-log record."""
from __future__ import annotations

from dataclasses import dataclass, asdict


@dataclass
class VisitRecord:
    id: int
    date: str       # ISO format YYYY-MM-DD
    referrer: str   # normalised lowercase, e.g. "google", "direct"
    page: str       # landing page path, e.g. "/pricing"
    visits: int     # number of visits (0 .. MAX_VISITS)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "VisitRecord":
        return cls(
            id=int(d["id"]),
            date=str(d["date"]),
            referrer=str(d["referrer"]),
            page=str(d.get("page", "/")),
            visits=int(d["visits"]),
        )
