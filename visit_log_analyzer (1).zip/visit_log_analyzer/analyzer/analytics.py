"""Core business logic: summarise visits by day and referrer, trends, warnings."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from statistics import mean, pstdev
from typing import Any

from .models import VisitRecord

# Warning thresholds (tweak here)
SPIKE_Z = 2.0            # day total this many std-devs above mean
DOMINANCE_SHARE = 50.0   # one referrer > 50% of all traffic
TREND_BAND = 5.0         # +/-5% half-over-half change counts as "stable"
MIN_DAYS_FOR_SPIKE = 5


def summarize_by_day(records: list[VisitRecord]) -> list[dict]:
    totals: dict[str, int] = defaultdict(int)
    counts: dict[str, int] = defaultdict(int)
    for r in records:
        totals[r.date] += r.visits
        counts[r.date] += 1
    return [{"date": d, "visits": totals[d], "entries": counts[d]} for d in sorted(totals)]


def summarize_by_referrer(records: list[VisitRecord]) -> list[dict]:
    totals: dict[str, int] = defaultdict(int)
    for r in records:
        totals[r.referrer] += r.visits
    grand = sum(totals.values())
    rows = [{"referrer": k, "visits": v, "share": (v / grand * 100 if grand else 0.0)}
            for k, v in totals.items()]
    return sorted(rows, key=lambda x: (-x["visits"], x["referrer"]))


def day_referrer_matrix(records: list[VisitRecord]) -> tuple[list[str], list[str], dict]:
    days = sorted({r.date for r in records})
    refs = [row["referrer"] for row in summarize_by_referrer(records)]
    cell: dict[tuple[str, str], int] = defaultdict(int)
    for r in records:
        cell[(r.date, r.referrer)] += r.visits
    return days, refs, cell


def compute_trend(daily: list[dict]) -> tuple[str, float]:
    """Compare average of first half of days with the second half."""
    if len(daily) < 2:
        return "Not enough data", 0.0
    mid = len(daily) // 2
    first = mean(d["visits"] for d in daily[:mid])
    second = mean(d["visits"] for d in daily[mid:])
    change = ((second - first) / first * 100) if first else (100.0 if second else 0.0)
    if change > TREND_BAND:
        return "Rising", change
    if change < -TREND_BAND:
        return "Falling", change
    return "Stable", change


def find_warnings(records: list[VisitRecord], daily: list[dict], by_ref: list[dict]) -> list[str]:
    warnings: list[str] = []
    if len(daily) >= MIN_DAYS_FOR_SPIKE:
        vals = [d["visits"] for d in daily]
        mu, sd = mean(vals), pstdev(vals)
        if sd > 0:
            for d in daily:
                z = (d["visits"] - mu) / sd
                if z >= SPIKE_Z:
                    warnings.append(f"Traffic spike on {d['date']}: {d['visits']:,} visits "
                                    f"({z:.1f} std-devs above the daily mean of {mu:,.0f}).")
    for row in by_ref:
        if row["share"] > DOMINANCE_SHARE and len(by_ref) > 1:
            warnings.append(f"Referrer concentration: '{row['referrer']}' supplies "
                            f"{row['share']:.1f}% of all visits.")
    zero = [r for r in records if r.visits == 0]
    if zero:
        warnings.append(f"{len(zero)} entr{'y' if len(zero)==1 else 'ies'} recorded with 0 visits "
                        f"(first: {zero[0].date}, {zero[0].referrer}) - check for tracking gaps.")
    if daily:
        start = date.fromisoformat(daily[0]["date"])
        end = date.fromisoformat(daily[-1]["date"])
        present = {d["date"] for d in daily}
        missing = [(start + timedelta(n)).isoformat() for n in range((end - start).days + 1)
                   if (start + timedelta(n)).isoformat() not in present]
        if missing:
            shown = ", ".join(missing[:5]) + (" ..." if len(missing) > 5 else "")
            warnings.append(f"{len(missing)} day(s) have no data in the logged range: {shown}")
    return warnings


def executive_summary(records: list[VisitRecord]) -> dict[str, Any]:
    daily = summarize_by_day(records)
    by_ref = summarize_by_referrer(records)
    if not records:
        return {"empty": True}
    total = sum(d["visits"] for d in daily)
    peak = max(daily, key=lambda d: d["visits"])
    low = min(daily, key=lambda d: d["visits"])
    trend, change = compute_trend(daily)
    return {
        "empty": False,
        "total_visits": total,
        "entries": len(records),
        "days": len(daily),
        "referrers": len(by_ref),
        "avg_per_day": total / len(daily),
        "peak_day": peak,
        "lowest_day": low,
        "top_referrer": by_ref[0],
        "trend": trend,
        "trend_change_pct": change,
        "date_range": (daily[0]["date"], daily[-1]["date"]),
        "warnings": find_warnings(records, daily, by_ref),
    }
