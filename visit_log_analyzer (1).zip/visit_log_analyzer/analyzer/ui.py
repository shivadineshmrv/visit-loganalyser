"""Interactive, menu-driven terminal interface."""
from __future__ import annotations

import os
import sys
from pathlib import Path

from . import __version__
from .analytics import executive_summary
from .plotting import generate_charts, matplotlib_available, text_bar_chart
from .queries import search
from .report import (day_table, export_report, matrix_table, records_table,
                     referrer_table, summary_lines)
from .storage import Storage
from .validation import (Cancelled, prompt, validate_date, validate_menu_choice,
                         validate_optional_date, validate_optional_int,
                         validate_page, validate_referrer, validate_visits)

PAGE_SIZE = 10
_USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _USE_COLOR else text


def ok(msg: str) -> None:
    print(c("[OK] ", "32;1") + msg)


def err(msg: str) -> None:
    print(c("[!] ", "31;1") + msg)


def warn(msg: str) -> None:
    print(c("[WARNING] ", "33;1") + msg)


def banner() -> None:
    line = "=" * 58
    print(c(line, "36"))
    print(c("   WEBSITE VISIT LOG ANALYZER", "36;1") + c(f"   v{__version__}", "2"))
    print(c("   Summarise visits by day & referrer from CSV logs", "36"))
    print(c(line, "36"))


MENU = """
 1) Add a visit record          7) Executive summary + warnings
 2) View all records            8) Generate charts (PNG)
 3) Search / filter records     9) Export report (MD / TXT / CSV)
 4) Delete a record            10) Bulk import CSV
 5) Summary by day             11) Load bundled sample data
 6) Summary by referrer         0) Exit
 (type ':q' at any prompt to cancel the current action)
"""

VALID_CHOICES = {str(i) for i in range(0, 12)}


def paginate(records, page_size: int = PAGE_SIZE) -> None:
    if not records:
        print("No matching records.")
        return
    total_pages = (len(records) + page_size - 1) // page_size
    for p in range(total_pages):
        chunk = records[p * page_size:(p + 1) * page_size]
        print(records_table(chunk))
        print(f"Page {p + 1}/{total_pages}  ({len(records)} records)")
        if p < total_pages - 1:
            if input("Press Enter for next page, or 'q' to stop: ").strip().lower() == "q":
                break


def pick_referrer(store: Storage):
    refs = sorted({r.referrer for r in store.records})
    if not refs:
        return None
    print("Available referrers: " + ", ".join(refs))
    raw = input("Filter by referrer (blank = any): ").strip().lower()
    return raw or None


# ---------------- actions ----------------
def action_add(store: Storage) -> None:
    print(c("\n-- Add visit record --", "1"))
    date = prompt("Date (YYYY-MM-DD)", validate_date, on_error=err)
    referrer = prompt("Referrer (e.g. google, direct, twitter)", validate_referrer, on_error=err)
    page = prompt("Landing page path", validate_page, default="/", on_error=err)
    visits = prompt("Number of visits (0-1,000,000)", validate_visits, on_error=err)
    rec = store.add(date, referrer, page, visits)
    ok(f"Saved record #{rec.id}: {rec.date} | {rec.referrer} | {rec.page} | {rec.visits:,} visits")


def action_view(store: Storage) -> None:
    paginate(sorted(store.records, key=lambda r: (r.date, r.id)))


def action_search(store: Storage) -> None:
    print(c("\n-- Search / filter (leave blank to skip a filter) --", "1"))
    kw = input("Keyword (matches date, referrer, page): ").strip()
    ref = pick_referrer(store)
    d_from = prompt("From date (YYYY-MM-DD)", validate_optional_date, default="", on_error=err)
    d_to = prompt("To date (YYYY-MM-DD)", validate_optional_date, default="", on_error=err)
    min_v = prompt("Minimum visits", validate_optional_int, default="", on_error=err)
    results = search(store.records, kw, ref, d_from, d_to, min_v)
    print(f"\n{len(results)} record(s) found, {sum(r.visits for r in results):,} total visits.")
    paginate(results)


def action_delete(store: Storage) -> None:
    def vid(raw: str) -> int:
        if not raw.strip().isdigit():
            raise ValueError("Record ID must be a positive whole number.")
        return int(raw)
    rid = prompt("Record ID to delete", vid, on_error=err)
    target = next((r for r in store.records if r.id == rid), None)
    if target is None:
        err(f"No record with ID {rid}.")
        return
    confirm = input(f"Delete #{rid} ({target.date}, {target.referrer}, {target.visits:,})? [y/N]: ")
    if confirm.strip().lower() == "y":
        store.delete(rid)
        ok("Record deleted.")
    else:
        print("Cancelled.")


def need_data(store: Storage) -> bool:
    if not store.records:
        err("No data yet. Add records, import a CSV (10) or load sample data (11).")
        return False
    return True


def action_by_day(store: Storage) -> None:
    if need_data(store):
        print(day_table(store.records))


def action_by_referrer(store: Storage) -> None:
    if need_data(store):
        print(referrer_table(store.records))


def action_summary(store: Storage) -> None:
    if not need_data(store):
        return
    print(c("\n== EXECUTIVE SUMMARY ==", "1"))
    for line in summary_lines(store.records):
        print(line)
    s = executive_summary(store.records)
    print(c("\n== THRESHOLD WARNINGS ==", "1"))
    if s["warnings"]:
        for w in s["warnings"]:
            warn(w)
    else:
        ok("No anomalies detected.")
    print(c("\n== DAY x REFERRER ==", "1"))
    print(matrix_table(store.records))


def action_charts(store: Storage) -> None:
    if not need_data(store):
        return
    if not matplotlib_available():
        warn("matplotlib is not installed (pip install matplotlib). Showing text chart instead:\n")
        print(text_bar_chart(store.records))
        return
    paths = generate_charts(store.records, Path("charts"))
    for p in paths:
        ok(f"Chart saved: {p}")


def action_export(store: Storage) -> None:
    if not need_data(store):
        return
    paths = export_report(store.records, Path("reports"))
    for fmt, p in paths.items():
        ok(f"{fmt.upper():>3} report: {p}")


def action_import(store: Storage) -> None:
    default = str(Path("data") / "sample_legacy_with_errors.csv")
    path = prompt("Path to CSV file", lambda s: s.strip() or (_ for _ in ()).throw(ValueError("Path required.")),
                  default=default, on_error=err)
    try:
        imported, errors = store.import_csv(path)
    except FileNotFoundError:
        err(f"File not found: {path}")
        return
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        err(f"Could not import: {exc}")
        return
    ok(f"Imported {imported} row(s). Rejected {len(errors)} (details in data/import_errors.log).")
    for row_no, reason in errors[:10]:
        warn(f"row {row_no}: {reason}")
    if len(errors) > 10:
        print(f"   ... and {len(errors) - 10} more in the log.")


def action_sample(store: Storage) -> None:
    sample = Path("data") / "sample_visits.csv"
    if store.records and input("This appends to existing data. Continue? [y/N]: ").strip().lower() != "y":
        print("Cancelled.")
        return
    try:
        imported, errors = store.import_csv(sample)
    except (FileNotFoundError, ValueError) as exc:
        err(f"Could not load sample data: {exc}")
        return
    ok(f"Loaded {imported} sample records ({len(errors)} rejected).")


ACTIONS = {"1": action_add, "2": action_view, "3": action_search, "4": action_delete,
           "5": action_by_day, "6": action_by_referrer, "7": action_summary,
           "8": action_charts, "9": action_export, "10": action_import, "11": action_sample}


def run(data_dir: str = "data") -> None:
    store = Storage(data_dir)
    store.load()
    banner()
    for note in store.load_notes:
        warn(note)
    print(f"Loaded {len(store.records)} record(s) from {store.path}")
    try:
        while True:
            print(MENU)
            choice = prompt("Choose an option", validate_menu_choice(VALID_CHOICES), on_error=err)
            if choice == "0":
                break
            try:
                ACTIONS[choice](store)
            except Cancelled:
                print("Action cancelled.")
            except OSError as exc:  # disk/permission problems shouldn't crash the app
                err(f"File error: {exc}")
    except (EOFError, KeyboardInterrupt):
        print()
    print("Data saved. Goodbye!")
