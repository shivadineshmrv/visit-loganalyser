"""Regenerates data/sample_visits.csv, data/sample_visits.json and the legacy error demo CSV."""
import csv, json, random
from datetime import date, timedelta

random.seed(97)
refs = {"google": 220, "direct": 150, "twitter": 60, "linkedin": 55, "newsletter": 80, "github": 40}
pages = ["/", "/pricing", "/blog/launch", "/docs", "/signup"]
rows = []
start = date(2026, 11, 1)
for n in range(10):
    d = start + timedelta(days=n)
    if d.isoformat() == "2026-11-05":      # deliberate gap day -> "missing data" warning
        continue
    for ref in random.sample(list(refs), 4):
        base = refs[ref] * (1 + n * 0.04)  # gentle upward trend
        v = max(1, int(random.gauss(base, base * 0.12)))
        if d.isoformat() == "2026-11-07" and ref in ("google", "direct"):
            v *= 6                         # deliberate traffic spike
        rows.append([d.isoformat(), ref, random.choice(pages), v])

# boundary / edge cases
rows.append(["2026-11-03", "reddit", "/blog/launch", 0])        # zero visits
rows.append(["2026-11-09", "reddit", "/blog/launch", 1])        # minimum non-zero
rows.append(["2026-11-10", "bing", "/", 1000])
rows.sort(key=lambda r: (r[0], r[1]))
rows = rows[:46]

with open("data/sample_visits.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["date", "referrer", "page", "visits"]); w.writerows(rows)

with open("data/sample_visits.json", "w") as f:
    json.dump({"version": 1, "records": [
        {"id": i + 1, "date": r[0], "referrer": r[1], "page": r[2], "visits": r[3]} for i, r in enumerate(rows)]}, f, indent=2)

legacy = [["date", "referrer", "page", "visits"],
          ["2026-11-11", "Google ", "/pricing", "420"],       # ok (normalised)
          ["2026-11-11", "direct", "/", "310"],               # ok
          ["2026-13-45", "twitter", "/", "50"],               # bad date
          ["2026-11-12", "", "/docs", "80"],                  # blank referrer
          ["2026-11-12", "linkedin", "/", "abc"],             # non-numeric
          ["2026-11-12", "github", "/docs", "-15"],           # negative
          ["2026-11-13", "newsletter", "/signup", "99999999"],# above max
          ["2026-11-13", "google", "pricing page!", "200"],   # bad page
          ["2026-11-13", "google", "/blog/launch", "1,250"],  # ok (comma stripped)
          ["11/14/2026", "direct", "/", "300"]]               # wrong date format
with open("data/sample_legacy_with_errors.csv", "w", newline="") as f:
    csv.writer(f).writerows(legacy)
print(len(rows), "sample rows written")
