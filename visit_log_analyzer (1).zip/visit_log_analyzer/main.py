#!/usr/bin/env python3
"""Website Visit Log Analyzer - entry point.

Usage:  python main.py [--data-dir DATA_DIR]
"""
import argparse

from analyzer.ui import run


def main() -> None:
    parser = argparse.ArgumentParser(description="Website Visit Log Analyzer")
    parser.add_argument("--data-dir", default="data", help="folder for visits.json (default: data)")
    args = parser.parse_args()
    run(args.data_dir)


if __name__ == "__main__":
    main()
